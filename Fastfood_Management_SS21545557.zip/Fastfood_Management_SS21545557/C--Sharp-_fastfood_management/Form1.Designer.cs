﻿
namespace FastFood_management1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.closelbl = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.Datelbl = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.puddingTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.puddingCheck = new System.Windows.Forms.CheckBox();
            this.cokeCheck = new System.Windows.Forms.CheckBox();
            this.icecreamTexbox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cokeTextbox = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.dewCheck = new System.Windows.Forms.CheckBox();
            this.icecreamCheck = new System.Windows.Forms.CheckBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.dougnautTextbox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dewTextbox = new System.Windows.Forms.TextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.chocoShakeCheck = new System.Windows.Forms.CheckBox();
            this.dougnautCheck = new System.Windows.Forms.CheckBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.mintshakeTextbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chocoshakeTextbox = new System.Windows.Forms.TextBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.mintShakeCheck = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.meatballTextbox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.meatballCheck = new System.Windows.Forms.CheckBox();
            this.swarmaTextbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.swarmaCHeck = new System.Windows.Forms.CheckBox();
            this.noodlesTextbox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.noodlesCheck = new System.Windows.Forms.CheckBox();
            this.pastaTextbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pastaCheck = new System.Windows.Forms.CheckBox();
            this.pizzaTextbox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pizzaCheck = new System.Windows.Forms.CheckBox();
            this.burgerTextbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.burgerCheck = new System.Windows.Forms.CheckBox();
            this.friesTextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.friesCheck = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel8 = new System.Windows.Forms.Panel();
            this.totallbl = new System.Windows.Forms.Label();
            this.vatlbl = new System.Windows.Forms.Label();
            this.subTotallbl = new System.Windows.Forms.Label();
            this.printBtn = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.receiptTextbox = new System.Windows.Forms.RichTextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Red;
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Controls.Add(this.panel5);
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1325, 117);
            this.flowLayoutPanel1.TabIndex = 1;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(4, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(267, 106);
            this.panel6.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(279, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(219, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(506, 4);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(415, 106);
            this.panel5.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Jokerman", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(4, 23);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(391, 63);
            this.label2.TabIndex = 6;
            this.label2.Text = "Siam\'s Fast Food";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pictureBox17);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Controls.Add(this.closelbl);
            this.panel7.Controls.Add(this.pictureBox16);
            this.panel7.Controls.Add(this.Datelbl);
            this.panel7.Location = new System.Drawing.Point(4, 118);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(393, 106);
            this.panel7.TabIndex = 4;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(96, 30);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(55, 32);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 35;
            this.pictureBox17.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MistyRose;
            this.label1.Location = new System.Drawing.Point(147, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 27);
            this.label1.TabIndex = 34;
            this.label1.Text = "Fast Meal";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // closelbl
            // 
            this.closelbl.AutoSize = true;
            this.closelbl.BackColor = System.Drawing.Color.IndianRed;
            this.closelbl.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closelbl.ForeColor = System.Drawing.Color.MistyRose;
            this.closelbl.Location = new System.Drawing.Point(353, 0);
            this.closelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.closelbl.Name = "closelbl";
            this.closelbl.Size = new System.Drawing.Size(34, 36);
            this.closelbl.TabIndex = 33;
            this.closelbl.Text = "X";
            this.closelbl.Click += new System.EventHandler(this.closelbl_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(96, 62);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(55, 32);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 32;
            this.pictureBox16.TabStop = false;
            // 
            // Datelbl
            // 
            this.Datelbl.AutoSize = true;
            this.Datelbl.BackColor = System.Drawing.Color.Transparent;
            this.Datelbl.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelbl.ForeColor = System.Drawing.Color.MistyRose;
            this.Datelbl.Location = new System.Drawing.Point(147, 62);
            this.Datelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Datelbl.Name = "Datelbl";
            this.Datelbl.Size = new System.Drawing.Size(130, 31);
            this.Datelbl.TabIndex = 31;
            this.Datelbl.Text = "Fast Meal";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.puddingTextbox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.pictureBox15);
            this.panel2.Controls.Add(this.puddingCheck);
            this.panel2.Controls.Add(this.cokeCheck);
            this.panel2.Controls.Add(this.icecreamTexbox);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.cokeTextbox);
            this.panel2.Controls.Add(this.pictureBox10);
            this.panel2.Controls.Add(this.dewCheck);
            this.panel2.Controls.Add(this.icecreamCheck);
            this.panel2.Controls.Add(this.pictureBox14);
            this.panel2.Controls.Add(this.dougnautTextbox);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.dewTextbox);
            this.panel2.Controls.Add(this.pictureBox11);
            this.panel2.Controls.Add(this.chocoShakeCheck);
            this.panel2.Controls.Add(this.dougnautCheck);
            this.panel2.Controls.Add(this.pictureBox13);
            this.panel2.Controls.Add(this.mintshakeTextbox);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.chocoshakeTextbox);
            this.panel2.Controls.Add(this.pictureBox12);
            this.panel2.Controls.Add(this.mintShakeCheck);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1017, 117);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(308, 607);
            this.panel2.TabIndex = 4;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(119, 410);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(71, 24);
            this.label23.TabIndex = 63;
            this.label23.Text = "Cream";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(119, 283);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 24);
            this.label22.TabIndex = 62;
            this.label22.Text = "Shake";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(115, 214);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 24);
            this.label21.TabIndex = 61;
            this.label21.Text = "Shake";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(121, 135);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 24);
            this.label20.TabIndex = 60;
            this.label20.Text = "Dew";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(128, 65);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 24);
            this.label19.TabIndex = 59;
            this.label19.Text = "Cola";
            // 
            // puddingTextbox
            // 
            this.puddingTextbox.Enabled = false;
            this.puddingTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.puddingTextbox.Location = new System.Drawing.Point(212, 478);
            this.puddingTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.puddingTextbox.Multiline = true;
            this.puddingTextbox.Name = "puddingTextbox";
            this.puddingTextbox.Size = new System.Drawing.Size(51, 27);
            this.puddingTextbox.TabIndex = 55;
            this.puddingTextbox.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(28, 4);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 31);
            this.label4.TabIndex = 7;
            this.label4.Text = "Drinks- Dessert";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(107, 478);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 24);
            this.label12.TabIndex = 56;
            this.label12.Text = "Pudding";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(272, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(36, 607);
            this.panel3.TabIndex = 0;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(35, 458);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(64, 62);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 57;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(35, 43);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(64, 62);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 34;
            this.pictureBox15.TabStop = false;
            // 
            // puddingCheck
            // 
            this.puddingCheck.AutoSize = true;
            this.puddingCheck.Location = new System.Drawing.Point(7, 478);
            this.puddingCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.puddingCheck.Name = "puddingCheck";
            this.puddingCheck.Size = new System.Drawing.Size(18, 17);
            this.puddingCheck.TabIndex = 58;
            this.puddingCheck.UseVisualStyleBackColor = true;
            this.puddingCheck.CheckedChanged += new System.EventHandler(this.puddingCheck_CheckedChanged);
            // 
            // cokeCheck
            // 
            this.cokeCheck.AutoSize = true;
            this.cokeCheck.Location = new System.Drawing.Point(7, 63);
            this.cokeCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cokeCheck.Name = "cokeCheck";
            this.cokeCheck.Size = new System.Drawing.Size(18, 17);
            this.cokeCheck.TabIndex = 31;
            this.cokeCheck.UseVisualStyleBackColor = true;
            this.cokeCheck.CheckedChanged += new System.EventHandler(this.cokeCheck_CheckedChanged);
            // 
            // icecreamTexbox
            // 
            this.icecreamTexbox.Enabled = false;
            this.icecreamTexbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.icecreamTexbox.Location = new System.Drawing.Point(212, 407);
            this.icecreamTexbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.icecreamTexbox.Multiline = true;
            this.icecreamTexbox.Name = "icecreamTexbox";
            this.icecreamTexbox.Size = new System.Drawing.Size(51, 27);
            this.icecreamTexbox.TabIndex = 51;
            this.icecreamTexbox.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(128, 43);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 24);
            this.label18.TabIndex = 32;
            this.label18.Text = "Coca";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(136, 388);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 24);
            this.label13.TabIndex = 52;
            this.label13.Text = "Ice";
            // 
            // cokeTextbox
            // 
            this.cokeTextbox.Enabled = false;
            this.cokeTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cokeTextbox.Location = new System.Drawing.Point(212, 48);
            this.cokeTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cokeTextbox.Multiline = true;
            this.cokeTextbox.Name = "cokeTextbox";
            this.cokeTextbox.Size = new System.Drawing.Size(51, 31);
            this.cokeTextbox.TabIndex = 33;
            this.cokeTextbox.Text = "0";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(35, 388);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(64, 62);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 53;
            this.pictureBox10.TabStop = false;
            // 
            // dewCheck
            // 
            this.dewCheck.AutoSize = true;
            this.dewCheck.Location = new System.Drawing.Point(7, 129);
            this.dewCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dewCheck.Name = "dewCheck";
            this.dewCheck.Size = new System.Drawing.Size(18, 17);
            this.dewCheck.TabIndex = 38;
            this.dewCheck.UseVisualStyleBackColor = true;
            this.dewCheck.CheckedChanged += new System.EventHandler(this.dewCheck_CheckedChanged);
            // 
            // icecreamCheck
            // 
            this.icecreamCheck.AutoSize = true;
            this.icecreamCheck.Location = new System.Drawing.Point(7, 407);
            this.icecreamCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.icecreamCheck.Name = "icecreamCheck";
            this.icecreamCheck.Size = new System.Drawing.Size(18, 17);
            this.icecreamCheck.TabIndex = 54;
            this.icecreamCheck.UseVisualStyleBackColor = true;
            this.icecreamCheck.CheckedChanged += new System.EventHandler(this.icecreamCheck_CheckedChanged);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(35, 110);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(64, 62);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 37;
            this.pictureBox14.TabStop = false;
            // 
            // dougnautTextbox
            // 
            this.dougnautTextbox.Enabled = false;
            this.dougnautTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dougnautTextbox.Location = new System.Drawing.Point(212, 334);
            this.dougnautTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dougnautTextbox.Multiline = true;
            this.dougnautTextbox.Name = "dougnautTextbox";
            this.dougnautTextbox.Size = new System.Drawing.Size(51, 27);
            this.dougnautTextbox.TabIndex = 47;
            this.dougnautTextbox.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(107, 110);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 24);
            this.label17.TabIndex = 36;
            this.label17.Text = "Mountain";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(103, 336);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 24);
            this.label14.TabIndex = 48;
            this.label14.Text = "Dougnaut";
            // 
            // dewTextbox
            // 
            this.dewTextbox.Enabled = false;
            this.dewTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dewTextbox.Location = new System.Drawing.Point(212, 118);
            this.dewTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dewTextbox.Multiline = true;
            this.dewTextbox.Name = "dewTextbox";
            this.dewTextbox.Size = new System.Drawing.Size(51, 27);
            this.dewTextbox.TabIndex = 35;
            this.dewTextbox.Text = "0";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(35, 318);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(64, 62);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 49;
            this.pictureBox11.TabStop = false;
            // 
            // chocoShakeCheck
            // 
            this.chocoShakeCheck.AutoSize = true;
            this.chocoShakeCheck.Location = new System.Drawing.Point(7, 197);
            this.chocoShakeCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chocoShakeCheck.Name = "chocoShakeCheck";
            this.chocoShakeCheck.Size = new System.Drawing.Size(18, 17);
            this.chocoShakeCheck.TabIndex = 42;
            this.chocoShakeCheck.UseVisualStyleBackColor = true;
            this.chocoShakeCheck.CheckedChanged += new System.EventHandler(this.chocoShakeCheck_CheckedChanged);
            // 
            // dougnautCheck
            // 
            this.dougnautCheck.AutoSize = true;
            this.dougnautCheck.Location = new System.Drawing.Point(7, 337);
            this.dougnautCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dougnautCheck.Name = "dougnautCheck";
            this.dougnautCheck.Size = new System.Drawing.Size(18, 17);
            this.dougnautCheck.TabIndex = 50;
            this.dougnautCheck.UseVisualStyleBackColor = true;
            this.dougnautCheck.CheckedChanged += new System.EventHandler(this.dougnautCheck_CheckedChanged);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(35, 177);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(64, 62);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 41;
            this.pictureBox13.TabStop = false;
            // 
            // mintshakeTextbox
            // 
            this.mintshakeTextbox.Enabled = false;
            this.mintshakeTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mintshakeTextbox.Location = new System.Drawing.Point(212, 266);
            this.mintshakeTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mintshakeTextbox.Multiline = true;
            this.mintshakeTextbox.Name = "mintshakeTextbox";
            this.mintshakeTextbox.Size = new System.Drawing.Size(51, 27);
            this.mintshakeTextbox.TabIndex = 43;
            this.mintshakeTextbox.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(115, 192);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 24);
            this.label16.TabIndex = 40;
            this.label16.Text = "Choco";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(128, 261);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 24);
            this.label15.TabIndex = 44;
            this.label15.Text = "Mint";
            // 
            // chocoshakeTextbox
            // 
            this.chocoshakeTextbox.Enabled = false;
            this.chocoshakeTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chocoshakeTextbox.Location = new System.Drawing.Point(212, 197);
            this.chocoshakeTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chocoshakeTextbox.Multiline = true;
            this.chocoshakeTextbox.Name = "chocoshakeTextbox";
            this.chocoshakeTextbox.Size = new System.Drawing.Size(51, 27);
            this.chocoshakeTextbox.TabIndex = 39;
            this.chocoshakeTextbox.Text = "0";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(35, 246);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(64, 62);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 45;
            this.pictureBox12.TabStop = false;
            // 
            // mintShakeCheck
            // 
            this.mintShakeCheck.AutoSize = true;
            this.mintShakeCheck.Location = new System.Drawing.Point(7, 266);
            this.mintShakeCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mintShakeCheck.Name = "mintShakeCheck";
            this.mintShakeCheck.Size = new System.Drawing.Size(18, 17);
            this.mintShakeCheck.TabIndex = 46;
            this.mintShakeCheck.UseVisualStyleBackColor = true;
            this.mintShakeCheck.CheckedChanged += new System.EventHandler(this.mintShakeCheck_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InfoText;
            this.panel1.Controls.Add(this.meatballTextbox);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.meatballCheck);
            this.panel1.Controls.Add(this.swarmaTextbox);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.swarmaCHeck);
            this.panel1.Controls.Add(this.noodlesTextbox);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.noodlesCheck);
            this.panel1.Controls.Add(this.pastaTextbox);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pastaCheck);
            this.panel1.Controls.Add(this.pizzaTextbox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pizzaCheck);
            this.panel1.Controls.Add(this.burgerTextbox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.burgerCheck);
            this.panel1.Controls.Add(this.friesTextbox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.friesCheck);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 117);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(296, 607);
            this.panel1.TabIndex = 5;
            // 
            // meatballTextbox
            // 
            this.meatballTextbox.Enabled = false;
            this.meatballTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meatballTextbox.Location = new System.Drawing.Point(244, 478);
            this.meatballTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.meatballTextbox.Multiline = true;
            this.meatballTextbox.Name = "meatballTextbox";
            this.meatballTextbox.Size = new System.Drawing.Size(45, 27);
            this.meatballTextbox.TabIndex = 27;
            this.meatballTextbox.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(141, 478);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 24);
            this.label11.TabIndex = 28;
            this.label11.Text = "Meal Ball";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(77, 458);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(64, 62);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 29;
            this.pictureBox8.TabStop = false;
            // 
            // meatballCheck
            // 
            this.meatballCheck.AutoSize = true;
            this.meatballCheck.Location = new System.Drawing.Point(49, 478);
            this.meatballCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.meatballCheck.Name = "meatballCheck";
            this.meatballCheck.Size = new System.Drawing.Size(18, 17);
            this.meatballCheck.TabIndex = 30;
            this.meatballCheck.UseVisualStyleBackColor = true;
            this.meatballCheck.CheckedChanged += new System.EventHandler(this.meatballCheck_CheckedChanged);
            // 
            // swarmaTextbox
            // 
            this.swarmaTextbox.Enabled = false;
            this.swarmaTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.swarmaTextbox.Location = new System.Drawing.Point(244, 407);
            this.swarmaTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.swarmaTextbox.Multiline = true;
            this.swarmaTextbox.Name = "swarmaTextbox";
            this.swarmaTextbox.Size = new System.Drawing.Size(45, 27);
            this.swarmaTextbox.TabIndex = 23;
            this.swarmaTextbox.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(149, 407);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 24);
            this.label10.TabIndex = 24;
            this.label10.Text = "Swarma";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(77, 388);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(64, 62);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 25;
            this.pictureBox7.TabStop = false;
            // 
            // swarmaCHeck
            // 
            this.swarmaCHeck.AutoSize = true;
            this.swarmaCHeck.Location = new System.Drawing.Point(49, 407);
            this.swarmaCHeck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.swarmaCHeck.Name = "swarmaCHeck";
            this.swarmaCHeck.Size = new System.Drawing.Size(18, 17);
            this.swarmaCHeck.TabIndex = 26;
            this.swarmaCHeck.UseVisualStyleBackColor = true;
            this.swarmaCHeck.CheckedChanged += new System.EventHandler(this.swarmaCHeck_CheckedChanged);
            // 
            // noodlesTextbox
            // 
            this.noodlesTextbox.Enabled = false;
            this.noodlesTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noodlesTextbox.Location = new System.Drawing.Point(244, 337);
            this.noodlesTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.noodlesTextbox.Multiline = true;
            this.noodlesTextbox.Name = "noodlesTextbox";
            this.noodlesTextbox.Size = new System.Drawing.Size(45, 27);
            this.noodlesTextbox.TabIndex = 19;
            this.noodlesTextbox.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(149, 337);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 24);
            this.label9.TabIndex = 20;
            this.label9.Text = "Noodles";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(77, 318);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(64, 62);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 21;
            this.pictureBox6.TabStop = false;
            // 
            // noodlesCheck
            // 
            this.noodlesCheck.AutoSize = true;
            this.noodlesCheck.Location = new System.Drawing.Point(49, 337);
            this.noodlesCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.noodlesCheck.Name = "noodlesCheck";
            this.noodlesCheck.Size = new System.Drawing.Size(18, 17);
            this.noodlesCheck.TabIndex = 22;
            this.noodlesCheck.UseVisualStyleBackColor = true;
            this.noodlesCheck.CheckedChanged += new System.EventHandler(this.noodlesCheck_CheckedChanged);
            // 
            // pastaTextbox
            // 
            this.pastaTextbox.Enabled = false;
            this.pastaTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pastaTextbox.Location = new System.Drawing.Point(244, 266);
            this.pastaTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pastaTextbox.Multiline = true;
            this.pastaTextbox.Name = "pastaTextbox";
            this.pastaTextbox.Size = new System.Drawing.Size(45, 27);
            this.pastaTextbox.TabIndex = 15;
            this.pastaTextbox.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(149, 266);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "Pasta";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(77, 246);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(64, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 17;
            this.pictureBox5.TabStop = false;
            // 
            // pastaCheck
            // 
            this.pastaCheck.AutoSize = true;
            this.pastaCheck.Location = new System.Drawing.Point(49, 266);
            this.pastaCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pastaCheck.Name = "pastaCheck";
            this.pastaCheck.Size = new System.Drawing.Size(18, 17);
            this.pastaCheck.TabIndex = 18;
            this.pastaCheck.UseVisualStyleBackColor = true;
            this.pastaCheck.CheckedChanged += new System.EventHandler(this.pastaCheck_CheckedChanged);
            // 
            // pizzaTextbox
            // 
            this.pizzaTextbox.Enabled = false;
            this.pizzaTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pizzaTextbox.Location = new System.Drawing.Point(244, 197);
            this.pizzaTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pizzaTextbox.Multiline = true;
            this.pizzaTextbox.Name = "pizzaTextbox";
            this.pizzaTextbox.Size = new System.Drawing.Size(45, 27);
            this.pizzaTextbox.TabIndex = 11;
            this.pizzaTextbox.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(149, 197);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 24);
            this.label7.TabIndex = 12;
            this.label7.Text = "Pizza";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(77, 177);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(64, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pizzaCheck
            // 
            this.pizzaCheck.AutoSize = true;
            this.pizzaCheck.Location = new System.Drawing.Point(49, 197);
            this.pizzaCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pizzaCheck.Name = "pizzaCheck";
            this.pizzaCheck.Size = new System.Drawing.Size(18, 17);
            this.pizzaCheck.TabIndex = 14;
            this.pizzaCheck.UseVisualStyleBackColor = true;
            this.pizzaCheck.CheckedChanged += new System.EventHandler(this.pizzaCheck_CheckedChanged);
            // 
            // burgerTextbox
            // 
            this.burgerTextbox.Enabled = false;
            this.burgerTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burgerTextbox.Location = new System.Drawing.Point(244, 129);
            this.burgerTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.burgerTextbox.Multiline = true;
            this.burgerTextbox.Name = "burgerTextbox";
            this.burgerTextbox.Size = new System.Drawing.Size(45, 27);
            this.burgerTextbox.TabIndex = 7;
            this.burgerTextbox.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(149, 129);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 24);
            this.label6.TabIndex = 8;
            this.label6.Text = "Burger";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(77, 110);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(64, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // burgerCheck
            // 
            this.burgerCheck.AutoSize = true;
            this.burgerCheck.Location = new System.Drawing.Point(49, 129);
            this.burgerCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.burgerCheck.Name = "burgerCheck";
            this.burgerCheck.Size = new System.Drawing.Size(18, 17);
            this.burgerCheck.TabIndex = 10;
            this.burgerCheck.UseVisualStyleBackColor = true;
            this.burgerCheck.CheckedChanged += new System.EventHandler(this.burgerCheck_CheckedChanged);
            // 
            // friesTextbox
            // 
            this.friesTextbox.Enabled = false;
            this.friesTextbox.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friesTextbox.Location = new System.Drawing.Point(244, 63);
            this.friesTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.friesTextbox.Multiline = true;
            this.friesTextbox.Name = "friesTextbox";
            this.friesTextbox.Size = new System.Drawing.Size(45, 27);
            this.friesTextbox.TabIndex = 6;
            this.friesTextbox.Text = "0";
            this.friesTextbox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(149, 63);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 24);
            this.label5.TabIndex = 6;
            this.label5.Text = "Fries";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(77, 43);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // friesCheck
            // 
            this.friesCheck.AutoSize = true;
            this.friesCheck.Location = new System.Drawing.Point(49, 63);
            this.friesCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.friesCheck.Name = "friesCheck";
            this.friesCheck.Size = new System.Drawing.Size(18, 17);
            this.friesCheck.TabIndex = 6;
            this.friesCheck.UseVisualStyleBackColor = true;
            this.friesCheck.CheckedChanged += new System.EventHandler(this.friesCheck_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(83, 4);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 31);
            this.label3.TabIndex = 6;
            this.label3.Text = "Fast Meal";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Yellow;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(41, 607);
            this.panel4.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Red;
            this.panel8.Controls.Add(this.totallbl);
            this.panel8.Controls.Add(this.vatlbl);
            this.panel8.Controls.Add(this.subTotallbl);
            this.panel8.Controls.Add(this.printBtn);
            this.panel8.Controls.Add(this.addBtn);
            this.panel8.Controls.Add(this.resetBtn);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(296, 601);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(721, 123);
            this.panel8.TabIndex = 6;
            // 
            // totallbl
            // 
            this.totallbl.AutoSize = true;
            this.totallbl.BackColor = System.Drawing.Color.Transparent;
            this.totallbl.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totallbl.ForeColor = System.Drawing.Color.Black;
            this.totallbl.Location = new System.Drawing.Point(580, 9);
            this.totallbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totallbl.Name = "totallbl";
            this.totallbl.Size = new System.Drawing.Size(47, 27);
            this.totallbl.TabIndex = 39;
            this.totallbl.Text = "Bdt";
            // 
            // vatlbl
            // 
            this.vatlbl.AutoSize = true;
            this.vatlbl.BackColor = System.Drawing.Color.Transparent;
            this.vatlbl.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vatlbl.ForeColor = System.Drawing.Color.Black;
            this.vatlbl.Location = new System.Drawing.Point(380, 9);
            this.vatlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.vatlbl.Name = "vatlbl";
            this.vatlbl.Size = new System.Drawing.Size(47, 27);
            this.vatlbl.TabIndex = 38;
            this.vatlbl.Text = "Bdt";
            // 
            // subTotallbl
            // 
            this.subTotallbl.AutoSize = true;
            this.subTotallbl.BackColor = System.Drawing.Color.Transparent;
            this.subTotallbl.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subTotallbl.ForeColor = System.Drawing.Color.Black;
            this.subTotallbl.Location = new System.Drawing.Point(127, 9);
            this.subTotallbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.subTotallbl.Name = "subTotallbl";
            this.subTotallbl.Size = new System.Drawing.Size(47, 27);
            this.subTotallbl.TabIndex = 37;
            this.subTotallbl.Text = "Bdt";
            // 
            // printBtn
            // 
            this.printBtn.BackColor = System.Drawing.Color.Gold;
            this.printBtn.FlatAppearance.BorderSize = 0;
            this.printBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.printBtn.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.printBtn.Location = new System.Drawing.Point(485, 58);
            this.printBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.printBtn.Name = "printBtn";
            this.printBtn.Size = new System.Drawing.Size(116, 37);
            this.printBtn.TabIndex = 36;
            this.printBtn.Text = "Print";
            this.printBtn.UseVisualStyleBackColor = false;
            this.printBtn.Click += new System.EventHandler(this.printBtn_Click);
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.Gold;
            this.addBtn.FlatAppearance.BorderSize = 0;
            this.addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addBtn.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.addBtn.Location = new System.Drawing.Point(269, 58);
            this.addBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(116, 37);
            this.addBtn.TabIndex = 35;
            this.addBtn.Text = "Add";
            this.addBtn.UseVisualStyleBackColor = false;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.BackColor = System.Drawing.Color.Gold;
            this.resetBtn.FlatAppearance.BorderSize = 0;
            this.resetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.resetBtn.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.resetBtn.Location = new System.Drawing.Point(45, 58);
            this.resetBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(116, 37);
            this.resetBtn.TabIndex = 34;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = false;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(516, 9);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(64, 27);
            this.label26.TabIndex = 33;
            this.label26.Text = "Total";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(273, 9);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(105, 27);
            this.label25.TabIndex = 32;
            this.label25.Text = "Vat(10%)";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(8, 9);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(102, 27);
            this.label24.TabIndex = 31;
            this.label24.Text = "SubTotal";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // receiptTextbox
            // 
            this.receiptTextbox.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.receiptTextbox.Location = new System.Drawing.Point(304, 124);
            this.receiptTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.receiptTextbox.Name = "receiptTextbox";
            this.receiptTextbox.Size = new System.Drawing.Size(704, 468);
            this.receiptTextbox.TabIndex = 7;
            this.receiptTextbox.Text = "";
            this.receiptTextbox.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 724);
            this.Controls.Add(this.receiptTextbox);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox friesCheck;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox friesTextbox;
        private System.Windows.Forms.TextBox puddingTextbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.CheckBox puddingCheck;
        private System.Windows.Forms.CheckBox cokeCheck;
        private System.Windows.Forms.TextBox icecreamTexbox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox cokeTextbox;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.CheckBox dewCheck;
        private System.Windows.Forms.CheckBox icecreamCheck;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.TextBox dougnautTextbox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox dewTextbox;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.CheckBox chocoShakeCheck;
        private System.Windows.Forms.CheckBox dougnautCheck;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.TextBox mintshakeTextbox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox chocoshakeTextbox;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.CheckBox mintShakeCheck;
        private System.Windows.Forms.TextBox meatballTextbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.CheckBox meatballCheck;
        private System.Windows.Forms.TextBox swarmaTextbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.CheckBox swarmaCHeck;
        private System.Windows.Forms.TextBox noodlesTextbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.CheckBox noodlesCheck;
        private System.Windows.Forms.TextBox pastaTextbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.CheckBox pastaCheck;
        private System.Windows.Forms.TextBox pizzaTextbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox pizzaCheck;
        private System.Windows.Forms.TextBox burgerTextbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox burgerCheck;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label Datelbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Label closelbl;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button printBtn;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox receiptTextbox;
        private System.Windows.Forms.Label totallbl;
        private System.Windows.Forms.Label vatlbl;
        private System.Windows.Forms.Label subTotallbl;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}

